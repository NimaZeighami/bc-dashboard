import packageJson from '../package.json';

// ----------------------------------------------------------------------

export type ConfigValue = {
  appName: string;
};

export const CONFIG: ConfigValue = {
  appName: 'BC Platform',
};
